# Dream Homes Real Estate Website
A simple static website for a real estate agency built with HTML and CSS.

## Pages
- Home (index.html)
- About (about.html)
- Properties (properties.html)
- Contact (contact.html)

## How to Deploy
1. Upload files to an EC2 instance under `/var/www/html/`
2. Ensure Apache is installed and running
3. Open the public IP in a browser